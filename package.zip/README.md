# sunset-fxos-addon
Addon for Firefox OS that works like f.lux

Tested on the Sony Z3 Compact (foxfood), install through WebIDE
